import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.awt.TextField;
import java.awt.Button;
import java.awt.Font;
import java.awt.Graphics2D;
import javax.swing.JComboBox;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
//import java.awt.Component;


public class Financials {

    // Database connection variables
    Connection conn = null;
    // Connection based on SQLite within the Project Folder
    String dbConnect = "jdbc:sqlite:../project/database/mamaspiddlins.sqlite";
    //  String dbConnect = "jdbc:sqlite:C:/Users/adria/Downloads/School/LR 2024-2025/Spring 2025/CSC 460/Work/Project/Project/database/mamaspiddlins.db";
    //  String dbUserName = "root";
    //  String dbPass = "root";
	
	public JFrame frame;
	public JTable tblFinacials;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Financials window = new Financials();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Financials() {
		try {
			conn = DriverManager.getConnection(dbConnect);
			System.out.println("Connection successful");
		}
		catch(SQLException e) {
			System.out.println("An error has occured during conection");
			e.printStackTrace();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		// Allows user to view a table with associated columns within the Finacials tab
		tblFinacials = new JTable();
		tblFinacials.setModel(new DefaultTableModel(
		new Object[][]{},
		new String[] {"Product ID", "Product Name", "Material Costs", "Sell Prices"}	
		));
		
		
		// The beginning setup for the Financials Page
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(new Color(216, 203, 175));
		frame.getContentPane().setLayout(null);
		
		// The panel that will contain the title of the page
		JPanel financialsPanel = new JPanel();
		financialsPanel.setBounds(10, 10, 166, 40);
		frame.getContentPane().add(financialsPanel);
		
		// The label that will display the title of the page
		JLabel lblFinancials = new JLabel("Financials");
		lblFinancials.setFont(new Font("Tahoma", Font.BOLD, 10));
		financialsPanel.add(lblFinancials);
		
		// A textfield to search within the database 
		TextField txtSearchBox = new TextField();
		txtSearchBox.setBounds(60, 120, 151, 21);
		frame.getContentPane().add(txtSearchBox);
		
		// A button to search within the database based on search textfield
		Button btnSearch = new Button("Search");
		btnSearch.setBounds(291, 120, 66, 21);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchFinancials(txtSearchBox.getText());
			}
		});
		btnSearch.setFont(new Font("Dialog", Font.BOLD, 12));
		frame.getContentPane().add(btnSearch);
		
		// Filtering options for user based on the associated options
		String[] sortOptions = new String [] {"Item Name", "Item Type", "Item Status"};
		JComboBox<String> cboxOption = new JComboBox<>(sortOptions);
		cboxOption.setBounds(542, 120, 141, 21);
		cboxOption.setSelectedIndex(2);
		cboxOption.setFont(new Font("Tahoma", Font.BOLD, 10));
		frame.getContentPane().add(cboxOption);
		
		// Allows user to view a table with associated columns within the Financials tab
		JScrollPane scrollPaneItems = new JScrollPane(tblFinacials);
		scrollPaneItems.setBounds(60, 170, 666, 408);
		scrollPaneItems.setForeground(Color.WHITE);
		frame.getContentPane().add(scrollPaneItems);
		
		// A panel background that will hold the button to return back to the background
		JPanel financialsBackgroundPanel = new JPanel();
		financialsBackgroundPanel.setBounds(10, 80, 755, 590);
		frame.getContentPane().add(financialsBackgroundPanel);
		financialsBackgroundPanel.setLayout(null);
		
		// A button to print a report based on the Financials table
		JButton btnPrintReport = new JButton("Print Report");
		btnPrintReport.setBounds(51, 536, 104, 21);
		financialsBackgroundPanel.add(btnPrintReport);
		
		// A panel background that holds all components on the screen
		JPanel homePanel = new JPanel();
		homePanel.setBounds(539, 10, 226, 48);
		frame.getContentPane().add(homePanel);
		homePanel.setLayout(null);
		
		// A button that will allow the user to return back to the home screen
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				Dashboard dashboardPage = new Dashboard();
				dashboardPage.frame.setVisible(true);
			}
		});
		btnHome.setBounds(50, 10, 132, 28);
		homePanel.add(btnHome);
		
		
		// A button that will print a report based on the current financials page
		btnPrintReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				printReport();
			}
		});
		
		// Will call the function to display all information based on the time log column from database
		viewFinacials();
		
	}
	
	// Function to allow the user to search for finances 
	private void searchFinancials(String financeProduct){
		if (financeProduct == null || financeProduct.trim().isEmpty()) {
			JOptionPane.showMessageDialog(frame, "Search bar cannot be empty", "Validation Error", JOptionPane.WARNING_MESSAGE);
			return;
		}
	}
	
	// Function to print the report and save it to a file 
	private void printReport() {
		try {
			// Ensure the directory exists
			File directory = new File("images");
            if (!directory.exists()) {
                directory.mkdirs(); // Create the directory if it doesn't exist
            }
            
            // Capture the content of the JFrame
			BufferedImage image = new BufferedImage(frame.getWidth(), frame.getHeight(), BufferedImage.TYPE_INT_RGB);
			Graphics2D graphics = image.createGraphics();
			
            // Render the frame to the image
			frame.paint(graphics);
			
            // Save the image to a file (PNG format)
			File file = new File("reports/financialReport.png");
			ImageIO.write(image, "PNG", file);
			
			JOptionPane.showMessageDialog(frame, "Report exported successfully!", "Export Success", JOptionPane.INFORMATION_MESSAGE);

		} catch(IOException ex) {
			JOptionPane.showMessageDialog(frame, "Error exporting report: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}

	}
	
	// Function to allow the user to fetch finacials information
	private void viewFinacials() {
		String query = "SELECT * FROM items";
		try(PreparedStatement stmt = conn.prepareStatement(query)){
			ResultSet rs = stmt.executeQuery();
			
			DefaultTableModel model = (DefaultTableModel) tblFinacials.getModel();
			model.setRowCount(0);
			
			while(rs.next()) {
				model.addRow(new Object[] {
						rs.getInt("ITEM_ID"),
						rs.getString("ITEM_NM"),
						rs.getBigDecimal("MATERIAL_COST_AM")
				});
			}
			
	        // Disable editing in the table
			tblFinacials.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			tblFinacials.setDefaultEditor(Object.class, null);  // Disable editor for the entire table
			tblFinacials.getTableHeader().setReorderingAllowed(false);

		} catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
}
