import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
//import java.awt.Component;

public class TimeLog {

    // Database connection variables
	Connection conn = null;
    String dbConnect = "jdbc:sqlite:../project/database/mamaspiddlins.sqlite";
	String dbUserName = "root";
	String dbPass = "root";
	
	public JFrame frame;
	private JTable tblTime;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TimeLog window = new TimeLog();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TimeLog() {
		try {
			conn = DriverManager.getConnection(dbConnect);
			System.out.println("Connection successful");
		}
		catch(SQLException e) {
			System.out.println("An error has occured during conection");
			e.printStackTrace();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		// Has to be initialized first before the rest to load the data
		// Allows user to view a table with associated columns within the Time tab
		tblTime = new JTable();
		tblTime.setModel(new DefaultTableModel(
		new Object[][]{},
		new String[] {"Time Log ID", "Item ID", "Time Spent (in hours) "}	
		));
		
		// Main screen for the application
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(new Color(216, 203, 175));
		frame.getContentPane().setLayout(null);
		
		// The panel that will contain the title of the page
		JPanel timeLogPanel = new JPanel();
		timeLogPanel.setBounds(29, 21, 166, 40);
		frame.getContentPane().add(timeLogPanel);
		
		// The label that will display the title of the page
		JLabel lblTimeLog = new JLabel("Time Log");
		lblTimeLog.setFont(new Font("Tahoma", Font.BOLD, 10));
		timeLogPanel.add(lblTimeLog);
		
		// Will use a table to display information to the user based on time
		JScrollPane scrollPaneTime = new JScrollPane(tblTime);
		scrollPaneTime.setForeground(Color.WHITE);
		scrollPaneTime.setBounds(87, 180, 437, 321);
		frame.getContentPane().add(scrollPaneTime);
		
		// A textfield to input search for components from the time table
		TextField txtSearchTimeLog = new TextField();
		txtSearchTimeLog.setBounds(87, 140, 151, 21);
		frame.getContentPane().add(txtSearchTimeLog);
		
		// A button to be used with the associated textfield to search for a specific time 
		JButton btnSearchTime = new JButton("Search");
		btnSearchTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchTimeLog(txtSearchTimeLog.getText());
			}
		});
		btnSearchTime.setFont(new Font("Dialog", Font.BOLD, 12));
		btnSearchTime.setBounds(264, 140, 110, 21);
		frame.getContentPane().add(btnSearchTime);
		
		// A background panel that will be used for decoration for the page
		JPanel backgroundPanel = new JPanel();
		backgroundPanel.setBounds(29, 100, 610, 507);
		frame.getContentPane().add(backgroundPanel);
		backgroundPanel.setLayout(null);
		
		// A panel background that holds all components on the screen
		JPanel homePanel = new JPanel();
		homePanel.setBounds(435, 21, 204, 55);
		frame.getContentPane().add(homePanel);
		homePanel.setLayout(null);
		
		// A button that will allow the user to return back to the home screen
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				Dashboard dashboardPage = new Dashboard();
				dashboardPage.frame.setVisible(true);
			}
		});
		btnHome.setBounds(28, 10, 150, 35);
		homePanel.add(btnHome);
	
		
		// Will call the function to display all information based on the time log column from database
		viewTimeLog();
		
	}
	
	// Function to allow the user to fetch time log information
	private void viewTimeLog() {
		String query = "SELECT * FROM time_logs";
		try(PreparedStatement stmt = conn.prepareStatement(query)){
	        ResultSet rs = stmt.executeQuery();
			
			DefaultTableModel model = (DefaultTableModel) tblTime.getModel();
			model.setRowCount(0);
			
			while (rs.next()) {
				model.addRow(new Object[] {
					rs.getInt("TIME_LOG_ID"),
					rs.getInt("ITEM_ID"),
					rs.getInt("TIME_SPENT_NO")				
				});
			}
	        // Disable editing in the table
			tblTime.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			tblTime.setDefaultEditor(Object.class, null);  // Disable editor for the entire table
			tblTime.getTableHeader().setReorderingAllowed(false);

		} catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	
	// Function to allow the user to fetch and search time log information
	// FIX ME
	private void searchTimeLog(String timeLog) {
		if (timeLog == null || timeLog.trim().isEmpty()){
			JOptionPane.showMessageDialog(frame, "Search bar cannot be empty", "Validation Error", JOptionPane.WARNING_MESSAGE);
			return;
		}
		
		String query = "SELECT * FROM TIME_LOGS WHERE ITEM_ID = ?";
		try(PreparedStatement pst = conn.prepareStatement(query)){
			pst.setString(1, timeLog);
			
			ResultSet rs = pst.executeQuery();
            DefaultTableModel model = new DefaultTableModel(
                    new String[]{"TIME_LOG_ID", "ITEM_ID", "TIME_SPENT_NO"}, 0);
            
            boolean found = false;
            
            while(rs.next()) {
            	found = true;
            	model.addRow(new Object [] {
            			rs.getInt("TIME_LOG_ID"),
            			rs.getInt("ITEM_ID"),
            			rs.getInt("TIME_SPENT_NO")
            	});
            }
            
            if(!found) {
                JOptionPane.showMessageDialog(frame, "No product found with the ID '" + timeLog + "'.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
    		tblTime.setModel(model);
            
		} catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Error fetching data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();	
		}

	}
}
