import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

import java.awt.Color;
import java.awt.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;

import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
//import java.awt.Component;

public class TimeLog {

    // Database connection variables
	Connection conn = null;
    String dbConnect = "jdbc:sqlite:../project/database/mamaspiddlins.sqlite";
	String dbUserName = "root";
	String dbPass = "root";
	
	public JFrame frmTimeLog;
	private JTable tblTime;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TimeLog window = new TimeLog();
					window.frmTimeLog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TimeLog() {
		try {
			conn = DriverManager.getConnection(dbConnect);
			System.out.println("Connection successful");
		}
		catch(SQLException e) {
			System.out.println("An error has occured during conection");
			e.printStackTrace();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		// Has to be initialized first before the rest to load the data
		// Allows user to view a table with associated columns within the Time tab
		tblTime = new JTable();
		tblTime.setModel(new DefaultTableModel(
			    new Object[][]{},
			    new String[] {"Time Log ID", "Item ID", "Time Spent (in hours)", "Item Name"}  // Added 'Item Name' column
			));

        // Disable editing in the table
		tblTime.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblTime.setDefaultEditor(Object.class, null);  // Disable editor for the entire table
		tblTime.getTableHeader().setReorderingAllowed(false);
		tblTime.getTableHeader().setReorderingAllowed(false);
		
		// Will be used to allow sorting for the tables by ascending/descending order
		TableRowSorter<DefaultTableModel> timeSorter = new TableRowSorter<>((DefaultTableModel) tblTime.getModel());
		tblTime.setRowSorter(timeSorter);

		// Will allow the sorting by column header
		tblTime.getTableHeader().addMouseListener(new java.awt.event.MouseAdapter() {
		    public void mouseClicked(java.awt.event.MouseEvent evt) {
		        int column = tblTime.columnAtPoint(evt.getPoint());
		        if (column >= 0) {
		            // Get current sort order for the column
		            boolean ascending = timeSorter.getSortKeys().isEmpty() || timeSorter.getSortKeys().get(0).getSortOrder() == SortOrder.DESCENDING;
		            // Toggle between ascending and descending
		            timeSorter.setSortKeys(Collections.singletonList(new RowSorter.SortKey(column, ascending ? SortOrder.ASCENDING : SortOrder.DESCENDING)));
		        }
	        }
	    });	
				
		// Main screen for the application
		frmTimeLog = new JFrame();
		frmTimeLog.setTitle("Time Log");
		frmTimeLog.setBounds(100, 100, 700, 700);
		frmTimeLog.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmTimeLog.getContentPane().setBackground(new Color(216, 203, 175));
		frmTimeLog.getContentPane().setLayout(null);
		
		// The panel that will contain the title of the page
		JPanel timeLogPanel = new JPanel();
		timeLogPanel.setBounds(29, 21, 166, 40);
		frmTimeLog.getContentPane().add(timeLogPanel);
		
		// The label that will display the title of the page
		JLabel lblTimeLog = new JLabel("Time Log");
		lblTimeLog.setFont(new Font("Tahoma", Font.BOLD, 10));
		timeLogPanel.add(lblTimeLog);
		
		// Will use a table to display information to the user based on time
		JScrollPane scrollPaneTime = new JScrollPane(tblTime);
		scrollPaneTime.setForeground(Color.WHITE);
		scrollPaneTime.setBounds(87, 180, 497, 321);
		frmTimeLog.getContentPane().add(scrollPaneTime);
		
		// A textfield to input search for components from the time table
		TextField txtSearchTimeLog = new TextField();
		txtSearchTimeLog.setBounds(87, 140, 151, 21);
		frmTimeLog.getContentPane().add(txtSearchTimeLog);
		
		// A button to be used with the associated textfield to search for a specific time 
		JButton btnSearchTime = new JButton("Search");
		btnSearchTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchTimeLog(txtSearchTimeLog.getText());
			}
		});
		btnSearchTime.setFont(new Font("Dialog", Font.BOLD, 12));
		btnSearchTime.setBounds(264, 140, 110, 21);
		frmTimeLog.getContentPane().add(btnSearchTime);
		
		// A background panel that will be used for decoration for the page
		JPanel backgroundPanel = new JPanel();
		backgroundPanel.setBounds(29, 100, 610, 507);
		frmTimeLog.getContentPane().add(backgroundPanel);
		backgroundPanel.setLayout(null);
		
		// A panel background that holds all components on the screen
		JPanel homePanel = new JPanel();
		homePanel.setBounds(435, 21, 204, 55);
		frmTimeLog.getContentPane().add(homePanel);
		homePanel.setLayout(null);
		
		// A button that will allow the user to return back to the home screen
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmTimeLog.setVisible(false);
				Dashboard dashboardPage = new Dashboard();
				dashboardPage.frmDashboard.setVisible(true);
			}
		});
		btnHome.setBounds(28, 10, 150, 35);
		homePanel.add(btnHome);
	
		
		// Will call the function to display all information based on the time log column from database
		viewTimeLog();
		
	}
	
	// Function to allow the user to fetch time log information
	private void viewTimeLog() {
	    // Modified query to join time_logs and items tables
	    String query = "SELECT tl.TIME_LOG_ID, tl.ITEM_ID, tl.TIME_SPENT_NO, i.ITEM_NM " +
	                   "FROM time_logs tl " +
	                   "JOIN items i ON tl.ITEM_ID = i.ITEM_ID";
	    
	    try (PreparedStatement stmt = conn.prepareStatement(query)) {
	        ResultSet rs = stmt.executeQuery();
	        
	        DefaultTableModel model = (DefaultTableModel) tblTime.getModel();
	        model.setRowCount(0);  // Clear existing rows

	        // Assuming result set has 4 columns
	        while (rs.next()) {
	            model.addRow(new Object[] {
	                rs.getInt("TIME_LOG_ID"),
	                rs.getInt("ITEM_ID"),
	                rs.getInt("TIME_SPENT_NO"),
	                rs.getString("ITEM_NM")
	            });
	        }


	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}

	
	
	// Function to allow the user to fetch and search time log information
	// FIX ME
	private void searchTimeLog(String timeLog) {
	    // Check if the input is empty or contains non-numeric characters
	    if (timeLog == null || timeLog.trim().isEmpty()) {
	        JOptionPane.showMessageDialog(frmTimeLog, "Search bar cannot be empty. Please enter a valid value.", "Validation Error", JOptionPane.WARNING_MESSAGE);
	        return;
	    }

	    try {
	        // Check if the entered value can be converted to an integer
	        Integer.parseInt(timeLog); // This will throw an exception if the input is not a valid integer

	        // Modify the query to select ITEM_NM as well (similar to viewTimeLog)
	        String query = "SELECT tl.TIME_LOG_ID, tl.ITEM_ID, tl.TIME_SPENT_NO, i.ITEM_NM " +
	                       "FROM time_logs tl " +
	                       "JOIN items i ON tl.ITEM_ID = i.ITEM_ID " +
	                       "WHERE tl.ITEM_ID = ?"; // Search by ITEM_ID

	        try (PreparedStatement pst = conn.prepareStatement(query)) {
	            pst.setString(1, timeLog);

	            ResultSet rs = pst.executeQuery();
	            DefaultTableModel model = new DefaultTableModel(
	                    new String[]{"TIME_LOG_ID", "ITEM_ID", "TIME_SPENT_NO", "ITEM_NM"}, 0); // Make sure the model has 4 columns

	            boolean found = false;

	            while (rs.next()) {
	                found = true;
	                model.addRow(new Object[]{
	                        rs.getInt("TIME_LOG_ID"),
	                        rs.getInt("ITEM_ID"),
	                        rs.getInt("TIME_SPENT_NO"),
	                        rs.getString("ITEM_NM") // Fetch ITEM_NM
	                });
	            }

	            if (!found) {
	                JOptionPane.showMessageDialog(frmTimeLog, "No product found with the ID '" + timeLog + "'.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
	                return;
	            }
	            tblTime.setModel(model);

	        } catch (SQLException ex) {
	            JOptionPane.showMessageDialog(frmTimeLog, "Error fetching data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            ex.printStackTrace();
	        }

	    } catch (NumberFormatException e) {
	        JOptionPane.showMessageDialog(frmTimeLog, "Invalid input. Please enter a valid value.", "Input Error", JOptionPane.ERROR_MESSAGE);
	    }
	}


}
