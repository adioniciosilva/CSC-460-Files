import java.awt.EventQueue;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
// import java.awt.ScrollPane;
import java.awt.TextField;
import java.awt.Button;
// import javax.swing.table.DefaultTableModel;



public class Dashboard {
	
    // Database connection variables
    Connection conn = null;
    String dbConnect = "jdbc:mysql://localhost:3306/mamapiddlin";
    String dbUserName = "root";
    String dbPass = "root";
    

	private JFrame frame;
	public JTable tblItems;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard window = new Dashboard();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Dashboard() {
		try {
			conn = DriverManager.getConnection(dbConnect, dbUserName, dbPass);
			System.out.println("Connection successful");
		}
		catch(SQLException e) {
			System.out.println("An error has occured during conection");
			e.printStackTrace();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(216, 203, 175));
		frame.getContentPane().setLayout(null);
		
		JPanel panelDashboard = new JPanel();
		panelDashboard.setBounds(31, 69, 125, 28);
		frame.getContentPane().add(panelDashboard);
		
		JLabel lblNewLabel = new JLabel("Dashboard");
		panelDashboard.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 10));
			
		
		// Creates a table to display the options for the item once searched
		tblItems = new JTable();
		tblItems.setModel(new DefaultTableModel(
		new Object[][]{},
		new String[] {"ID", "Name", "Pattern", "Status"}
		
		));
		
		JScrollPane scrollPaneItems = new JScrollPane(tblItems);
		scrollPaneItems.setForeground(new Color(255, 255, 255));
		scrollPaneItems.setBounds(24, 153, 437, 163);
		frame.getContentPane().add(scrollPaneItems);
		
		
		TextField txtSearchBox = new TextField();
		txtSearchBox.setBounds(21, 120, 151, 21);
		frame.getContentPane().add(txtSearchBox);
		
		Button btnSearch = new Button("Search");
		btnSearch.setFont(new Font("Dialog", Font.BOLD, 12));
		btnSearch.setBounds(190, 120, 66, 21);
		frame.getContentPane().add(btnSearch);
		
		// Sorting for the items
		String[] sortOptions = new String [] {"Option 1", "Option 2", "Option 3"};
		JComboBox<String> cboxOption = new JComboBox<>(sortOptions);
		cboxOption.setFont(new Font("Tahoma", Font.BOLD, 10));
		cboxOption.setSelectedIndex(2); // Due to indices starting at 0, specifies Option 3
		cboxOption.setBounds(296, 120, 141, 21);
		frame.getContentPane().add(cboxOption);
		
		JButton btnSettings = new JButton("Settings");
		btnSettings.setFont(new Font("Tahoma", Font.BOLD, 10));
		btnSettings.setBounds(347, 56, 90, 28);
		frame.getContentPane().add(btnSettings);
		
		JPanel panelmage = new JPanel();
		panelmage.setBounds(31, 344, 125, 28);
		frame.getContentPane().add(panelmage);
		
		JLabel lblImage = new JLabel("Image");
		lblImage.setFont(new Font("Tahoma", Font.BOLD, 10));
		panelmage.add(lblImage);
		
		JPanel panelTimeLog = new JPanel();
		panelTimeLog.setBounds(261, 344, 125, 28);
		frame.getContentPane().add(panelTimeLog);
		
		JLabel lblTimeLog = new JLabel("Time Log");
		lblTimeLog.setFont(new Font("Tahoma", Font.BOLD, 10));
		panelTimeLog.add(lblTimeLog);
		
		JLabel lblImageDisplay = new JLabel("");
		lblImageDisplay.setBounds(31, 393, 141, 116);
		frame.getContentPane().add(lblImageDisplay);
		
		JLabel lblTimeDisplay = new JLabel("");
		lblTimeDisplay.setBounds(256, 393, 141, 116);
		frame.getContentPane().add(lblTimeDisplay);
		
		
		frame.setBounds(100, 100, 500, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
