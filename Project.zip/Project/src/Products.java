import java.awt.Color;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import java.awt.Font;
// import java.awt.Component;

public class Products {
    // Database connection variables
    Connection conn = null;
    // Connection based on SQLite within the Project Folder
    String dbConnect = "jdbc:sqlite:../project/database/mamaspiddlins.sqlite";
    //  String dbConnect = "jdbc:sqlite:C:/Users/adria/Downloads/School/LR 2024-2025/Spring 2025/CSC 460/Work/Project/Project/database/mamaspiddlins.db";
    //  String dbUserName = "root";
    //  String dbPass = "root";
	
	public JFrame frmProducts;
	public JTable tblFinacials;
	public JTable tblTime;
	public JTable tblList;
	public JTable tblProducts;
	private JTextField txtProdName;
	private JTextField txtProdPattern;
	private JTextField txtMaterialCost;
	private JTextField txtProdDSPrices;
	private JTextField txtTimeSpent;
	private JTextField txtProductDelId;
	private JComboBox<String> cboxProductStatusAdd;
	private JComboBox<String> cboxDonSelAdd;
	private JComboBox<String> cboxCoozieSize;
	private JTextField txtProductId;
	private JTextField txtItemType;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Products window = new Products();
					window.frmProducts.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Products() {
		try {
			conn = DriverManager.getConnection(dbConnect);
			System.out.println("Connection successful");
		}
		catch(SQLException e) {
			System.out.println("An error has occured during conection");
			e.printStackTrace();
		}
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		// The beginning setup for the Products Page
		frmProducts = new JFrame();
		frmProducts.setTitle("Products");
		frmProducts.setBounds(100, 100, 1000, 1000);
		frmProducts.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProducts.getContentPane().setBackground(new Color(216, 203, 175));
		frmProducts.getContentPane().setLayout(null);
		
		// The main panel for the panes, with each a represented tab
		JTabbedPane mainPanel = new JTabbedPane(JTabbedPane.TOP);
		mainPanel.setBounds(51, 85, 903, 678);
		frmProducts.getContentPane().add(mainPanel);
		
		JPanel panelAddProd = new JPanel();
		mainPanel.addTab("Add Product", null, panelAddProd, null);
		panelAddProd.setLayout(null);
		
		JPanel panelEditProd = new JPanel();
		mainPanel.addTab("Edit Product", null, panelEditProd, null);
		panelEditProd.setLayout(null);
		
		JPanel panelDeleteProd = new JPanel();
		mainPanel.addTab("Delete Product", null, panelDeleteProd, null);
		panelDeleteProd.setLayout(null);
		
//		*******************************************************************************************************		
//		Add Products Components
		
		// A label that will display to the user product name
		JLabel lblProductName = new JLabel("Product Name");
		lblProductName.setBounds(95, 75, 90, 13);
		panelAddProd.add(lblProductName);
		
		// A textfield to add new products based on product name into database 
		txtProdName = new JTextField();
		txtProdName.setToolTipText("Insert Product Name");
		txtProdName.setBounds(276, 72, 179, 19);
		panelAddProd.add(txtProdName);
		txtProdName.setColumns(10);
		
		// A label that will display to the user coozie size
		JLabel lblCoozieSize = new JLabel("Coozie Size");
		lblCoozieSize.setBounds(95, 110, 114, 13);
		panelAddProd.add(lblCoozieSize);
		
		// A textfield to add new products based on coozie size into database 
		String[] sortCoozieSize = new String [] {"","Small", "Medium", "Large"};
		cboxCoozieSize = new JComboBox<>(sortCoozieSize);
		cboxCoozieSize.setBounds(276, 101, 179, 21);
		panelAddProd.add(cboxCoozieSize);
		
		// A label that will display to the user item type
		JLabel lblItemType = new JLabel("Item Type");
		lblItemType.setBounds(95, 144, 114, 13);
		panelAddProd.add(lblItemType);
		
		// A textfield to add new products based on item type into database 
		txtItemType = new JTextField();
		txtItemType.setBounds(276, 141, 179, 19);
		panelAddProd.add(txtItemType);
		txtItemType.setColumns(10);
		
		
		// A label that will display to the user quilt pattern
		JLabel lblQuiltPattern = new JLabel("Quilt Pattern");
		lblQuiltPattern.setBounds(95, 182, 90, 13);
		panelAddProd.add(lblQuiltPattern);
		
		// A textfield to add new products based on product pattern into database 
		txtProdPattern = new JTextField();
		txtProdPattern.setBounds(276, 179, 179, 19);
		txtProdPattern.setColumns(10);
		panelAddProd.add(txtProdPattern);
		
		// A label that will display to the user product status
		JLabel lblProductStatus = new JLabel("Product Status");
		lblProductStatus.setBounds(95, 223, 90, 13);
		panelAddProd.add(lblProductStatus);
		
		// A combobox to add new products based on product status into database 
		String[] sortStatus = new String[] {"Finished", "Not Started", "Not Finished"};
		cboxProductStatusAdd = new JComboBox<>(sortStatus);
		cboxProductStatusAdd.setBounds(276, 219, 179, 21);
		panelAddProd.add(cboxProductStatusAdd);
		
		// A textfield to add new products based on material costs into database 
		txtMaterialCost = new JTextField();	
		txtMaterialCost.setBounds(276, 265, 179, 19);
		txtMaterialCost.setColumns(10);
		panelAddProd.add(txtMaterialCost);
		
		// A label that will display to the user product material costs
		JLabel lblProductMC = new JLabel("Product Material Costs");
		lblProductMC.setBounds(95, 268, 135, 13);
		panelAddProd.add(lblProductMC);
		
		// A label that will display to the user product category
		JLabel lblProductCategory = new JLabel("Product Category");
		lblProductCategory.setBounds(95, 310, 135, 13);
		panelAddProd.add(lblProductCategory);
		
		// A combobox to add new products based on product category into database 
		String[] sortCategory = new String [] {"Inventory", "Sell", "Donate"};
		cboxDonSelAdd = new JComboBox<>(sortCategory);
		cboxDonSelAdd.setBounds(276, 306, 179, 21);
		panelAddProd.add(cboxDonSelAdd);
		
		// A label that will display to the user product sell prices
		JLabel lblProductDSPrices = new JLabel("Product Sell Prices");
		lblProductDSPrices.setBounds(95, 357, 161, 13);
		panelAddProd.add(lblProductDSPrices);
		
		// A textfield to add new products based on product sell price into database 
		txtProdDSPrices = new JTextField();
		txtProdDSPrices.setBounds(276, 354, 179, 19);
		txtProdDSPrices.setColumns(10);
		panelAddProd.add(txtProdDSPrices);
		
		// A label that will display to the user time spent
		JLabel lblProductTimeSpent = new JLabel("Time Spent (in hours)");
		lblProductTimeSpent.setBounds(95, 401, 161, 13);
		panelAddProd.add(lblProductTimeSpent);
		
		// A textfield to add new products based on product's time spent into database 
		txtTimeSpent = new JTextField();
		txtTimeSpent.setBounds(276, 398, 179, 19);
		txtTimeSpent.setColumns(10);
		panelAddProd.add(txtTimeSpent);
		
		// A button to add a new product based on the associated fields
		JButton btnAddProd = new JButton("Add Product");
		btnAddProd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Calls the function to  add the product to the database
				addProduct();
			}
		});
		btnAddProd.setBounds(140, 450, 114, 21);
		panelAddProd.add(btnAddProd);
		
		//A button to cancel adding a new product based on the associated fields
		JButton btnCancelProd = new JButton("Cancel Product");
		btnCancelProd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//
				txtProdName.setText("");
				txtItemType.setText("");
				txtProdPattern.setText("");
				txtMaterialCost.setText("");
				txtProdDSPrices.setText("");
				txtTimeSpent.setText("");
			}
		});
		btnCancelProd.setBounds(285, 450, 135, 21);
		panelAddProd.add(btnCancelProd);
		
		
		// The panel that will contain the title of the page
		JPanel productPanel = new JPanel();
		productPanel.setBounds(51, 24, 166, 40);
		frmProducts.getContentPane().add(productPanel);
		
		// The label that will display the title of the page
		JLabel lblProduct = new JLabel("Products");
		lblProduct.setFont(new Font("Tahoma", Font.BOLD, 10));
		productPanel.add(lblProduct);
		
		// A panel background that holds all components on the screen
		JPanel homePanel = new JPanel();
		homePanel.setBounds(719, 24, 235, 55);
		frmProducts.getContentPane().add(homePanel);
		homePanel.setLayout(null);
		
		
		// A button that will allow the user to return back to the home screen
		JButton btnHome = new JButton("Home");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmProducts.setVisible(false);
				Dashboard dashboardPage = new Dashboard();
				dashboardPage.frmDashboard.setVisible(true);
			}
		});
		btnHome.setBounds(43, 10, 140, 35);
		homePanel.add(btnHome);

	
//		*******************************************************************************************************
//		Edit Products Components
		
		// Allow user to view a table with associated columns from the Items table
		tblProducts = new JTable();
		tblProducts.setModel(new DefaultTableModel(
		new Object[][] {},
		new String[] {"Product ID", "Product Name", "Product Type", "Product Status", "Product Pattern", "Product Category","Product Date", "Coozie Size", "Material Cost"}
		));
		
        // Disable editing in the table
		tblProducts.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblProducts.setDefaultEditor(Object.class, null);  // Disable editor for the entire table
		tblProducts.getTableHeader().setReorderingAllowed(false);
		
		// The table that that will display the information to the user 
		JScrollPane scrollPaneEditProduct = new JScrollPane(tblProducts);
		scrollPaneEditProduct.setBounds(19, 48, 879, 364);
		panelEditProd.add(scrollPaneEditProduct);
		
		// A label that will display to the user product id
		JLabel lblProductId = new JLabel("Product Id");
		lblProductId.setBounds(100, 437, 90, 13);
		panelEditProd.add(lblProductId);
		
		// A textfield to allow user to input product id to edit a product
		txtProductId = new JTextField();
		txtProductId.setColumns(10);
		txtProductId.setBounds(275, 434, 179, 19);
		panelEditProd.add(txtProductId);
		
		// A button to save your edits to the product
		JButton btnSaveProd = new JButton("Save Product");
		btnSaveProd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// FIX ME
				editProduct();
			}
		});
		btnSaveProd.setBounds(141, 473, 114, 21);
		panelEditProd.add(btnSaveProd);
		
		// A button to cancel your edits to the product
		JButton btnCancelChange = new JButton("Cancel Changes");
		btnCancelChange.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtProductId.setText("");
			}
		});
		btnCancelChange.setBounds(275, 473, 135, 21);
		panelEditProd.add(btnCancelChange);
		
		
//		*******************************************************************************************************
//		Delete Products Components
		
		// Allows user to view a table with associated columns within the Delete Product tab
		tblList = new JTable();
		tblList.setModel(new DefaultTableModel(
		new Object[][]{},
		new String[] {"Product ID", "Product Type", "Product Name"}
		));
		
		// The table that that will display the information to the user 
		JScrollPane scrollPaneList = new JScrollPane(tblList);
		scrollPaneList.setBounds(141, 82, 362, 230);
		panelDeleteProd.add(scrollPaneList);
		
		// A label that will display to the user product id
		JLabel lblProductDelId = new JLabel("Product ID");
		lblProductDelId.setBounds(141, 348, 90, 13);
		panelDeleteProd.add(lblProductDelId);
		
		// A textfield to allow user to input product id to remove a product
		txtProductDelId = new JTextField();
		txtProductDelId.setColumns(10);
		txtProductDelId.setBounds(327, 345, 179, 19);
		panelDeleteProd.add(txtProductDelId);
		
		// A button to delete a product with use of an associated textfield
		JButton btnDeleteProduct = new JButton("Delete Product");
		btnDeleteProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// FIX ME
				deleteProduct(Integer.parseInt(txtProductDelId.getText()));
			}
		});
		btnDeleteProduct.setBounds(194, 386, 124, 21);
		panelDeleteProd.add(btnDeleteProduct);
		
		// A button to cancel the deletion of a product 
		JButton btnCancelChanges = new JButton("Cancel Product");
		btnCancelChanges.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtProductDelId.setText("");
			}
		});
		btnCancelChanges.setBounds(328, 386, 135, 21);
		panelDeleteProd.add(btnCancelChanges);
				
		
//		*******************************************************************************************************
		
		// Will call the function to display all information based on the time log column from database
		viewProductInfo();
		editProductInfo();
	}
	
	// FIX ME
	private void editProduct() {
		
	}
	
	// FIX ME
	private void addProduct(){
		String prodName = txtProdName.getText();
		String prodPattern = txtProdPattern.getText();
		String materialCostCB = txtMaterialCost.getText();
//		String prodDSPricesCB = txtProdDSPrices.getText();
//		String timeSpentHr = txtTimeSpent.getText();
		String productStatus = (String) cboxProductStatusAdd.getSelectedItem();
		String category = (String) cboxDonSelAdd.getSelectedItem();
		
	    // Check if combo boxes are properly initialized
	    if (cboxProductStatusAdd == null || cboxDonSelAdd == null) {
	        JOptionPane.showMessageDialog(frmProducts, "Combo boxes are not initialized!", "Initialization Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

//		if(prodName.trim().isEmpty() || prodPattern.trim().isEmpty() || materialCostCB.trim().isEmpty() ||
//				prodDSPricesCB.trim().isEmpty() || timeSpentHr.trim().isEmpty()) {
//			JOptionPane.showMessageDialog(frame, "Please fill in all the required fields.", "Validation error", JOptionPane.WARNING_MESSAGE);
//			return;
//		}
		
		double materialCost = 0.0;
//		double prodDSPrices = 0.0;
//		int timeSpent = 0;
		
		try {
			materialCost = Double.parseDouble(materialCostCB);
//			prodDSPrices = Double.parseDouble(prodDSPricesCB);
//			timeSpent = Integer.parseInt(timeSpentHr);
			
		} catch(NumberFormatException ex) {
			JOptionPane.showMessageDialog(frmProducts, "Please enter valid values for cost and time.", "Input Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		String query = "INSERT INTO items (ITEM_NM, QUILT_PATTERN_CD, ITEM_STATUS_CD, CATEGORY_CD, MATERIAL_COST_AM, ITEM_STATUS_CD)"
				+ "VALUES (?, ?, ?, ?, ?, ?)";
		
		
//		String query = "INSERT INTO items (ITEM_NM, QUILT_PATTERN_CD, ITEM_STATUS_CD, CATEGORY, MATERIAL_COST, PROD_DS_PRICES, TIME_SPENT)"
//				+ "VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		try(PreparedStatement stmt = conn.prepareStatement(query)){
			stmt.setString(1, prodName);
			stmt.setString(2, prodPattern);
			stmt.setString(3, productStatus);
			stmt.setDouble(4, materialCost);
			stmt.setString(5, category);
//			stmt.setDouble(6, prodDSPrices);
//			stmt.setInt(7, timeSpent);
			
			int rowsInserted = stmt.executeUpdate();
			
			if(rowsInserted > 0) {
				JOptionPane.showMessageDialog(frmProducts, "Product added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
	            // Optionally, clear the fields after successful insert
	            txtProdName.setText("");
	            txtProdPattern.setText("");
	            txtMaterialCost.setText("");
//	            txtProdDSPrices.setText("");
//	            txtTimeSpent.setText("");
	            cboxProductStatusAdd.setSelectedIndex(0);
	            cboxDonSelAdd.setSelectedIndex(0);
			}
		} catch(SQLException ex) {
			JOptionPane.showMessageDialog(frmProducts, "An error occurred while adding the product. Please try again.", "Database Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	// TEST THIS
	private void deleteProduct(int productDelete) {
	    if (productDelete == 0) {
	        JOptionPane.showMessageDialog(frmProducts, "Product ID cannot be zero or empty.", "Validation Error", JOptionPane.WARNING_MESSAGE);
	        return;
	    }

	    // Step 1: Check if the product exists in the TIME_LOGS table
	    String checkQuery = "SELECT * FROM time_logs WHERE ITEM_ID = ?";
	    try (PreparedStatement pst = conn.prepareStatement(checkQuery)) {
	        pst.setInt(1, productDelete);
	        
	        ResultSet rs = pst.executeQuery();
	        DefaultTableModel model = new DefaultTableModel(
	            new String[]{"TIME_LOG_ID", "ITEM_ID", "TIME_SPENT_NO"}, 0);
	        
	        boolean found = false;

	        // Loop through the result set to check if the product exists
	        while (rs.next()) {
	            found = true;
	            model.addRow(new Object[]{
	                rs.getInt("TIME_LOG_ID"),
	                rs.getInt("ITEM_ID"),
	                rs.getInt("TIME_SPENT_NO")
	            });
	        }

	        if (!found) {
	            // If no records are found, show a message
	            JOptionPane.showMessageDialog(frmProducts, "No product found with the ID '" + productDelete + "'.", "Search Result", JOptionPane.INFORMATION_MESSAGE);
	            return;
	        }

	        // Step 2: Delete product from the ITEMS table
	        String deleteQuery = "DELETE FROM ITEMS WHERE ITEM_ID = ?";
	        try (PreparedStatement pstDelete = conn.prepareStatement(deleteQuery)) {
	            pstDelete.setInt(1, productDelete);

	            int affectedRows = pstDelete.executeUpdate();
	            if (affectedRows > 0) {
	                JOptionPane.showMessageDialog(frmProducts, "Product deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
	                // Refresh the product list after deletion
	                viewProductInfo();
	            } else {
	                JOptionPane.showMessageDialog(frmProducts, "Error deleting the product.", "Error", JOptionPane.ERROR_MESSAGE);
	            }
	        } catch (SQLException e) {
	            JOptionPane.showMessageDialog(frmProducts, "Error while deleting the product: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            e.printStackTrace();
	        }

	    } catch (SQLException e) {
	        JOptionPane.showMessageDialog(frmProducts, "Error fetching time log data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	        e.printStackTrace();
	    }
	}
	
	// Function to allow the user to fetch product information
	private void viewProductInfo() {
		String query = "SELECT * FROM items";
		try(PreparedStatement stmt = conn.prepareStatement(query)){
			ResultSet rs = stmt.executeQuery();
			
			DefaultTableModel model = (DefaultTableModel) tblList.getModel();
			model.setRowCount(0);
			
			while (rs.next()) {
				model.addRow(new Object[] {
						rs.getInt("ITEM_ID"),
						rs.getString("ITEM_TYPE_DE"),
						rs.getString("ITEM_NM")
				});
			}
			
	        // Disable editing in the table
            tblList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            tblList.setDefaultEditor(Object.class, null);  // Disable editor for the entire table
            tblList.getTableHeader().setReorderingAllowed(false);

		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	// Function to allow the user to fetch and view product information to edit
	private void editProductInfo() {
		String query = "SELECT * FROM items";
		try(PreparedStatement stmt = conn.prepareStatement(query)){
			ResultSet rs = stmt.executeQuery();
			
			DefaultTableModel model = (DefaultTableModel) tblProducts.getModel();
			model.setRowCount(0);
			
			while (rs.next()) {
				model.addRow(new Object[] {
					rs.getInt("ITEM_ID"),
					rs.getString("ITEM_NM"),
					rs.getString("ITEM_TYPE_DE"),
					rs.getString("ITEM_STATUS_CD"),
					rs.getString("QUILT_PATTERN_CD"),
					rs.getString("CATEGORY_CD"),
					rs.getString("DATE_CREATED_DT"),
					rs.getString("COOZIE_SIZE_DE"),
					rs.getInt("MATERIAL_COST_AM")
				});
			}
		}catch(SQLException ex) {
		ex.printStackTrace();
		}
	}
}

	
